# SumadorGitHub
Suma dos dígitos en página.
